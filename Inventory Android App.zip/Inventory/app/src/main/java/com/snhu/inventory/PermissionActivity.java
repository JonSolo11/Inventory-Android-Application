package com.snhu.inventory;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;

public class PermissionActivity extends AppCompatActivity {

    private final int PERMISSIONS_REQUEST_CODE = 100; // Unique request code for permissions
    private boolean isSmsPermissionGranted = false; // Flag to track SMS permission status
    private boolean isNotificationPermissionGranted = false; // Flag to track Notification permission status

    private boolean isCameraPermissionGranted = false; // Flag to track SMS permission status

    private ItemDatabaseHelper dbHelper;

    User currentUser = User.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission); // Set the layout for this activity

        dbHelper = new ItemDatabaseHelper(this);

        checkAndRequestPermissions(); // Check and request necessary permissions

        createNotificationChannel(); // Create a notification channel for sending notifications

        checkInventoryAndNotify();

    }

    // Method to check and request SMS and Notification permissions
    private void checkAndRequestPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();

        // Check for each permission and add to the list if not granted
        isSmsPermissionGranted = ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        if (!isSmsPermissionGranted) permissionsNeeded.add(Manifest.permission.SEND_SMS);

        isNotificationPermissionGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        if (!isNotificationPermissionGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) permissionsNeeded.add(Manifest.permission.POST_NOTIFICATIONS);

        isCameraPermissionGranted = ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        if (!isCameraPermissionGranted) permissionsNeeded.add(Manifest.permission.CAMERA);

        // Request permissions if needed, else show a Toast message
        if (permissionsNeeded.size() > 0) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toArray(new String[0]), PERMISSIONS_REQUEST_CODE);
            Toast.makeText(this, "Permissions needed: " + permissionsNeeded, Toast.LENGTH_LONG).show();
        } else {
            // All permissions are already granted
            Toast.makeText(this, "All Permissions Granted", Toast.LENGTH_SHORT).show();
            proceedToMainActivity();
        }
    }

    private void proceedToMainActivity() {
        Intent mainIntent = new Intent(PermissionActivity.this, MainActivity.class);
        startActivity(mainIntent);
        finish();
    }


    // Callback method to handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                switch (permissions[i]) {
                    case Manifest.permission.SEND_SMS:
                        currentUser.setSmsPermissionGranted(grantResults[i] == PackageManager.PERMISSION_GRANTED);
                        break;
                    case Manifest.permission.POST_NOTIFICATIONS:
                        currentUser.setNotificationPermissionGranted(grantResults[i] == PackageManager.PERMISSION_GRANTED);
                        break;
                    case Manifest.permission.CAMERA:
                        currentUser.setCameraPermissionGranted(grantResults[i] == PackageManager.PERMISSION_GRANTED);
                        break;
                }
            }
        }

        // After handling permissions, navigate to MainActivity
        proceedToMainActivity();
    }


    // Method to check inventory and notify if necessary
    private void checkInventoryAndNotify() {

        List<InventoryItem> lowInventoryItems = dbHelper.getLowInventoryItems();

        if(lowInventoryItems.size() > 0){
            showLowInventoryNotification();
            sendLowInventorySMS();
            updateNotifications();
        }
    }

    // Method to show a notification for low inventory
    private void showLowInventoryNotification() {
        if (isNotificationPermissionGranted) {
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "inventory_channel")
                    .setSmallIcon(R.drawable.logo)
                    .setContentTitle("Low Inventory Alert")
                    .setContentText("Inventory is running low. Open application for details.")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.notify(1, builder.build());
            }
        } else {
            Toast.makeText(this, "Cannot show notification. Permission not granted.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateNotifications()
    {
        User user = User.getInstance();
        user.addNotification(new NotificationItem("Low Inventory", "Items in your inventory are out of stock"));
    }

    private void sendLowInventorySMS() {
        if(isSmsPermissionGranted) {
            String phoneNumber = "7349312311";
            String message = "Your inventory is running low. Please restock.";

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(PermissionActivity.this, "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to create a notification channel
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("inventory_channel", name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
