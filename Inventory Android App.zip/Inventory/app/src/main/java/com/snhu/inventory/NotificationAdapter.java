package com.snhu.inventory;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private List<NotificationItem> notificationItems;

    // Constructor to initialize the adapter with a list of notification items
    public NotificationAdapter(List<NotificationItem> items) {
        notificationItems = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the notification_item layout as a view for each list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.notification_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NotificationAdapter.ViewHolder holder, int position) {
        NotificationItem item = notificationItems.get(position);

        // Style changes based on read/unread status
        if (item.isRead()) {
            // Set text color to gray for read notifications
            holder.notificationTitle.setTextColor(Color.GRAY);
        } else {
            // Set text color to black for unread notifications
            holder.notificationTitle.setTextColor(Color.BLACK);
        }

        // Set notification title and content
        holder.notificationTitle.setText(item.getTitle());
        holder.notificationContent.setText(item.getContent());

        // Set an onClickListener to handle click events on notification items
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mark the notification as read and update UI
                item.setRead(true);
                notifyItemChanged(holder.getAdapterPosition());
            }
        });

        // Set notification title and content (duplicate lines removed)
        holder.notificationTitle.setText(item.getTitle());
        holder.notificationContent.setText(item.getContent());
    }

    @Override
    public int getItemCount() {
        return notificationItems.size();
    }

    // ViewHolder class to hold references to the views within each list item
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView notificationTitle, notificationContent;

        // Constructor to initialize the views in the ViewHolder
        public ViewHolder(View itemView) {
            super(itemView);
            notificationTitle = itemView.findViewById(R.id.notificationTitle);
            notificationContent = itemView.findViewById(R.id.notificationContent);
        }
    }
}
