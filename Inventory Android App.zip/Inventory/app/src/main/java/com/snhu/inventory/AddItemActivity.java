package com.snhu.inventory;

import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class AddItemActivity extends AppCompatActivity {
    // Constants and instance variables
    private static final int CAMERA_REQUEST_CODE = 1;
    private Uri imageUri;
    private EditText itemNameEditText, itemQuantityEditText, itemUpcEditText, itemPriceEditText;
    private ItemDatabaseHelper dbHelper;
    private InventoryItem currentItem;

    // Activity creation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize UI elements and check if in 'edit' mode
        initializeFields();
        if (getIntent().hasExtra("inventoryItem")) {
            currentItem = (InventoryItem) getIntent().getSerializableExtra("inventoryItem");
            populateFields(currentItem);
            setButtonText("SAVE");
        } else {
            setButtonText("Add Item");
        }
    }

    // Initialize UI elements and set click listeners
    private void initializeFields() {
        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        itemUpcEditText = findViewById(R.id.itemUpcEditText);
        itemPriceEditText = findViewById(R.id.itemPriceEditText);
        dbHelper = new ItemDatabaseHelper(this);

        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(v -> addItemToDatabase());

        ImageButton scanUpcButton = findViewById(R.id.scanUpcButton);
        scanUpcButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startBarcodeScan();
            }
        });

        Button chooseImageButton = findViewById(R.id.buttonChooseImage);
        chooseImageButton.setOnClickListener(v -> openImageChooser());
    }

    // Set button text
    private void setButtonText(String text) {
        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setText(text);
    }

    // Start barcode scanning
    private void startBarcodeScan() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.initiateScan();
    }

    // Populate fields with item data
    private void populateFields(InventoryItem item) {
        itemNameEditText.setText(item.getName());
        itemQuantityEditText.setText(String.valueOf(item.getQuantity()));
        itemUpcEditText.setText(item.getUpc());
        itemPriceEditText.setText(String.format("%.2f", item.getPrice()));
        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty() && !item.getImageUrl().equals("default_image")) {
            imageUri = Uri.parse(item.getImageUrl());
            ImageView selectedImageView = findViewById(R.id.itemImageView);
            selectedImageView.setImageURI(imageUri);
        } else {
            ImageView selectedImageView = findViewById(R.id.itemImageView);
            selectedImageView.setImageResource(R.drawable.default_image);
        }
    }

    // Add or update an item in the database
    private void addItemToDatabase() {
        String itemName = itemNameEditText.getText().toString();
        int quantity = Integer.parseInt(itemQuantityEditText.getText().toString());
        String upc = itemUpcEditText.getText().toString();
        double price = Double.parseDouble(itemPriceEditText.getText().toString());
        String imageUrl = imageUri != null ? imageUri.toString() : null;

        if (currentItem != null) {
            currentItem.setName(itemName);
            currentItem.setQuantity(quantity);
            currentItem.setUpc(upc);
            currentItem.setPrice(price);
            currentItem.setImageUrl(imageUrl);
            dbHelper.updateItem(currentItem);
        } else {
            InventoryItem newItem = new InventoryItem(itemName, quantity, upc, imageUrl, price);
            dbHelper.addItem(newItem);
            Intent resultIntent = new Intent();
            resultIntent.putExtra("newItem", newItem);
            setResult(RESULT_OK, resultIntent);
        }

        Intent resultIntent = new Intent();
        resultIntent.putExtra("updatedItem", currentItem);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    // Open the image chooser for capturing a photo
    private void openImageChooser() {
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePhotoIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePhotoIntent, CAMERA_REQUEST_CODE);
        }
    }

    // Handle activity results (barcode scan, image capture, and item update)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IntentIntegrator.REQUEST_CODE && resultCode == RESULT_OK) {
            IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
            if (result != null) {
                if (result.getContents() != null) {
                    String scannedUpc = result.getContents();
                    itemUpcEditText.setText(scannedUpc);
                }
            }
        }

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            if (extras != null) {
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                imageUri = saveImageToInternalStorage(imageBitmap);
                ImageView selectedImageView = findViewById(R.id.itemImageView);
                selectedImageView.setImageBitmap(imageBitmap);
            }
        }

        if (resultCode == RESULT_OK) {
            if (data != null && data.hasExtra("updatedItem")) {
                InventoryItem updatedItem = (InventoryItem) data.getSerializableExtra("updatedItem");
                populateFields(updatedItem);
            } else if (data != null && data.hasExtra("newItem")) {
                InventoryItem newItem = (InventoryItem) data.getSerializableExtra("newItem");
                populateFields(newItem);
            }
        }
    }

    // Save captured image to internal storage and return its URI
    private Uri saveImageToInternalStorage(Bitmap bitmap) {
        ContextWrapper wrapper = new ContextWrapper(getApplicationContext());
        File file = wrapper.getDir("Images", MODE_PRIVATE);
        file = new File(file, "UniqueFileName" + ".jpg");

        try {
            OutputStream stream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
            stream.flush();
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return Uri.parse(file.getAbsolutePath());
    }
}
