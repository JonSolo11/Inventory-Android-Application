package com.snhu.inventory;

import java.util.ArrayList;
import java.util.List;

public class User {
    private static User instance;

    // User properties
    private boolean isSmsPermissionGranted;
    private boolean isNotificationPermissionGranted;
    private boolean isCameraPermissionGranted;
    private String phoneNumber;

    private List<NotificationItem> notifications;

    // Private constructor to prevent instantiation
    private User() {
        notifications = new ArrayList<>();
    }

    // Static method to get the instance
    public static synchronized User getInstance() {
        if (instance == null) {
            instance = new User();
        }
        return instance;
    }

    // Getters and setters for user properties
    public boolean isSmsPermissionGranted() {
        return isSmsPermissionGranted;
    }

    public void setSmsPermissionGranted(boolean isSmsPermissionGranted) {
        this.isSmsPermissionGranted = isSmsPermissionGranted;
    }

    public boolean isNotificationPermissionGranted() {
        return isNotificationPermissionGranted;
    }

    public void setNotificationPermissionGranted(boolean isNotificationPermissionGranted) {
        this.isNotificationPermissionGranted = isNotificationPermissionGranted;
    }

    public boolean isCameraPermissionGranted() {
        return isCameraPermissionGranted;
    }

    public void setCameraPermissionGranted(boolean isCameraPermissionGranted) {
        this.isCameraPermissionGranted = isCameraPermissionGranted;
    }

    // Getters and setters for notifications
    public List<NotificationItem> getNotifications() {
        return notifications;
    }

    public void addNotification(NotificationItem notification) {
        notifications.add(notification);
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }


}

