package com.snhu.inventory;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SearchInventoryAdapter extends RecyclerView.Adapter<SearchInventoryAdapter.ViewHolder> {

    private List<InventoryItem> inventoryItems;
    private Context context;

    // Define the listener interface
    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    // Listener field
    private OnItemClickListener onItemClickListener;

    // Method to set the listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    public SearchInventoryAdapter(List<InventoryItem> inventoryItems, Context context) {
        this.inventoryItems = inventoryItems;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_search_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        InventoryItem item = inventoryItems.get(position);
        holder.itemNameTextView.setText(item.getName());
        holder.itemUpcTextView.setText(item.getUpc());

        // Load and display item images from a URL
        if (item.getImageUrl() != null && !item.getImageUrl().equals("default_image")) {
            Uri imageUri = Uri.parse(item.getImageUrl());
            holder.itemImageView.setImageURI(imageUri);
        } else {
            // Display a default image if no image URL is available
            holder.itemImageView.setImageResource(R.drawable.default_image);
        }
    }

    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemNameTextView, itemUpcTextView;
        ImageView itemImageView;

        ViewHolder(View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemUpcTextView = itemView.findViewById(R.id.itemUpcTextView);
            itemImageView = itemView.findViewById(R.id.itemImageView);

            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    InventoryItem item = inventoryItems.get(position);

                    // Handle item click by launching the ItemDetailActivity
                    Intent intent = new Intent(context, ItemDetailActivity.class);
                    intent.putExtra("itemId", item.getId()); // Pass the item ID to the ItemDetailActivity
                    context.startActivity(intent);
                }
            });
        }
    }
}
