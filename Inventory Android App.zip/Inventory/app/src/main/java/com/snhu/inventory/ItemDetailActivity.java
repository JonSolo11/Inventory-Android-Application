package com.snhu.inventory;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {

    private static final int ADD_ITEM_REQUEST_CODE = 1001;
    private int itemId;
    private String itemNameText;
    private int itemQuantity;
    private String itemUPCText;
    private String itemImageUrl;
    private double itemPrice;

    private ItemDatabaseHelper dbHelper;

    private TextView itemNameTextView, itemQuantityTextView, itemUpcTextView, itemPriceTextView;
    private ImageView itemImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        dbHelper = new ItemDatabaseHelper(this);
        itemImageView = findViewById(R.id.itemImageView);
        itemNameTextView = findViewById(R.id.itemNameTextView);
        itemQuantityTextView = findViewById(R.id.itemQuantityTextView);
        itemUpcTextView = findViewById(R.id.itemUpcTextView);
        itemPriceTextView = findViewById(R.id.itemPriceTextView);

        // Retrieve item ID from the intent
        Intent intent = getIntent();
        itemId = intent.getIntExtra("itemId", -1);

        // Load item details and set up edit and delete buttons
        loadItemDetails();
        setupEditAndDeleteButtons();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_ITEM_REQUEST_CODE && resultCode == RESULT_OK) {
            // Refresh item details after editing
            loadItemDetails();
        }
    }

    private void loadItemDetails() {
        // Load item details from the database using item ID
        InventoryItem item = dbHelper.getItemById(itemId);

        if (item != null) {
            itemNameText = item.getName();
            itemQuantity = item.getQuantity();
            itemUPCText = item.getUpc();
            itemImageUrl = item.getImageUrl();
            itemPrice = item.getPrice();

            // Update the UI with the loaded item details
            updateUI();
        }
    }

    private void updateUI() {
        // Update UI elements with item details
        if (itemImageUrl != null && !itemImageUrl.equals("default_image.jpg")) {
            Uri imageUri = Uri.parse(itemImageUrl);
            itemImageView.setImageURI(imageUri);
        } else {
            itemImageView.setImageResource(R.drawable.default_image);
        }

        itemNameTextView.setText("Item Name: " + itemNameText);
        itemQuantityTextView.setText("Quantity: " + itemQuantity);
        itemUpcTextView.setText("UPC: " + itemUPCText);
        itemPriceTextView.setText("Price: $" + String.format("%.2f", itemPrice));
    }

    private void setupEditAndDeleteButtons() {
        // Set up click listeners for edit and delete buttons
        Button editButton = findViewById(R.id.editItemButton);
        editButton.setOnClickListener(v -> {
            // Start the AddItemActivity to edit the item
            Intent intent = new Intent(ItemDetailActivity.this, AddItemActivity.class);
            InventoryItem itemToEdit = dbHelper.getItemById(itemId);
            intent.putExtra("inventoryItem", itemToEdit);
            startActivityForResult(intent, ADD_ITEM_REQUEST_CODE);
        });

        Button deleteButton = findViewById(R.id.deleteItemButton);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show a confirmation dialog before deleting the item
                showDeleteConfirmationDialog();
            }
        });
    }

    private void showDeleteConfirmationDialog() {
        // Show a confirmation dialog for item deletion
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Item");
        builder.setMessage("Are you sure you want to delete this item?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Delete the item when the user confirms
                deleteItem();
            }
        });
        builder.setNegativeButton("Cancel", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void deleteItem() {
        // Delete the item from the database and finish the activity
        if (dbHelper.deleteItem(itemId)) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error deleting item", Toast.LENGTH_SHORT).show();
        }
    }
}
