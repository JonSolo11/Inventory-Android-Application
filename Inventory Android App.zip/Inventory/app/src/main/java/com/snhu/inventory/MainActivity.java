package com.snhu.inventory;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Declare class-level variables
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private List<InventoryItem> inventoryItems;
    private ItemDatabaseHelper dbHelper;

    private boolean isSortAscending = true;
    private String currentSortField = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the database helper and item list
        dbHelper = new ItemDatabaseHelper(this);
        inventoryItems = new ArrayList<>();

        // Initialize the bottom navigation view
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setBackground(null);
        bottomNavigationView.getMenu().getItem(2).setEnabled(false);

        // Initialize the RecyclerView for displaying inventory items
        recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the adapter for the RecyclerView
        adapter = new InventoryAdapter(inventoryItems, dbHelper, this); // Context added to constructor
        recyclerView.setAdapter(adapter);

        // Set up the bottom navigation view
        setupBottomNavigationView();

        // Load items from the database
        loadItemsFromDatabase();

        // Set up various buttons and icons
        setupButtons();
        setupToolbarIcons();

        // Set up sorting buttons
        setupSortingButtons();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload items from the database every time MainActivity resumes
        loadItemsFromDatabase();
        // Update the notification badge
        updateNotificationBadge();

        // Reset sorting order and button states
        isSortAscending = true;
        setupSortingButtons(); // Method to reset button states
        reapplySort(); // Reapply sort to reset the list
    }

    // Set up buttons and their click actions
    private void setupButtons() {
        // Button to navigate to the PermissionActivity
        Button tempButtonToPermission = findViewById(R.id.tempButtonToPermission);
        tempButtonToPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to start the PermissionActivity
                Intent intent = new Intent(MainActivity.this, PermissionActivity.class);
                startActivity(intent);
            }
        });

        // Button to add a test item to the database
        Button addTestItemButton = findViewById(R.id.addTestItemButton);
        addTestItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTestItemToDatabase();
            }
        });

        // Floating Action Button for adding new inventory items
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });
    }

    // Set up click actions for toolbar icons
    private void setupToolbarIcons() {
        // Click action for the alerts icon
        ImageView alertsIcon = findViewById(R.id.alertsIcon);
        alertsIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NotificationsActivity.class);
                startActivity(intent);
            }
        });

        // Click action for the profile icon (TODO: implement)
        ImageView profileIcon = findViewById(R.id.profileIcon);
        profileIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: Implement profile menu
            }
        });
    }

    // Set up sorting buttons and their click actions
    private void setupSortingButtons() {
        ImageButton sortByNameIcon = findViewById(R.id.sortByNameIcon);
        ImageButton sortByQuantityIcon = findViewById(R.id.sortByQuantityIcon);
        ImageButton sortByUpcIcon = findViewById(R.id.sortByUpcIcon);
        ImageButton sortByPriceIcon = findViewById(R.id.sortByPriceIcon);
        ImageButton sortReverse = findViewById(R.id.sortReverse);

        // Click listener for sorting buttons
        View.OnClickListener sortClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reset all buttons to unselected state and set the clicked one to selected
                sortByNameIcon.setSelected(v.getId() == R.id.sortByNameIcon);
                sortByQuantityIcon.setSelected(v.getId() == R.id.sortByQuantityIcon);
                sortByUpcIcon.setSelected(v.getId() == R.id.sortByUpcIcon);
                sortByPriceIcon.setSelected(v.getId() == R.id.sortByPriceIcon);

                // Determine which field to sort by based on the clicked button
                if (v.getId() == R.id.sortByNameIcon) {
                    currentSortField = "name";
                } else if (v.getId() == R.id.sortByQuantityIcon) {
                    currentSortField = "quantity";
                } else if (v.getId() == R.id.sortByUpcIcon) {
                    currentSortField = "upc";
                } else if (v.getId() == R.id.sortByPriceIcon) {
                    currentSortField = "price";
                }

                reapplySort();
            }
        };

        sortByNameIcon.setOnClickListener(sortClickListener);
        sortByQuantityIcon.setOnClickListener(sortClickListener);
        sortByUpcIcon.setOnClickListener(sortClickListener);
        sortByPriceIcon.setOnClickListener(sortClickListener);

        // Click listener for the sort reverse button
        sortReverse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isSortAscending = !isSortAscending; // Toggle the sort order
                sortReverse.setSelected(isSortAscending); // Update reverse button state
                reapplySort(); // Reapply the current sort with the new order
            }
        });
    }

    // Reapply sorting based on the current field and order
    private void reapplySort() {
        switch (currentSortField) {
            case "name":
                adapter.sortByName(isSortAscending);
                break;
            case "quantity":
                adapter.sortByQuantity(isSortAscending);
                break;
            case "upc":
                adapter.sortByUpc(isSortAscending);
                break;
            case "price":
                adapter.sortByPrice(isSortAscending);
                break;
        }
    }

    // Update the notification badge visibility
    private void updateNotificationBadge() {
        ImageView notificationBadge = findViewById(R.id.alertsBadge);

        // Check if there are any unread notifications
        boolean hasUnreadNotifications = false;
        for (NotificationItem notification : User.getInstance().getNotifications()) {
            if (!notification.isRead()) {
                hasUnreadNotifications = true;
                break;
            }
        }

        // Show the badge only if there are unread notifications
        notificationBadge.setVisibility(hasUnreadNotifications ? View.VISIBLE : View.GONE);
    }

    // Set up the bottom navigation view and its item click actions
    private void setupBottomNavigationView() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;

                if (item.getItemId() == R.id.navigation_home) {
                    // Handle Home navigation
                    intent = new Intent(MainActivity.this, MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    startActivity(intent);
                    return true;
                } else if (item.getItemId() == R.id.navigation_search) {
                    // Handle Search navigation
                    intent = new Intent(MainActivity.this, SearchActivity.class);
                    startActivity(intent);
                    return true;
                } else if (item.getItemId() == R.id.navigation_barcode) {
                    intent = new Intent(MainActivity.this, SearchActivity.class);
                    intent.putExtra("barcodeScannerEnabled", true); // Extra flag to enable barcode scanner
                    startActivity(intent);
                    return true;
                } else if (item.getItemId() == R.id.navigation_low_inventory) {
                    loadLowInventoryItems();
                    return true;
                }

                return false;
            }
        });
    }

    // Load low inventory items from the database and update the list
    private void loadLowInventoryItems() {
        // Clear the current list and load only low inventory items
        inventoryItems.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(ItemDatabaseHelper.TABLE_INVENTORY, null,
                ItemDatabaseHelper.COLUMN_QUANTITY + " = 0",
                null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_ID);
                int nameIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_ITEM_NAME);
                int quantityIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_QUANTITY);
                int upcIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_UPC);
                int imageUrlIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_IMAGE_URL);
                int priceIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_PRICE);

                // Read each item from the cursor and add it to the list
                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                int quantity = cursor.getInt(quantityIndex);
                String upc = cursor.getString(upcIndex);
                String imageUrl = cursor.getString(imageUrlIndex);
                double price = cursor.getDouble(priceIndex);

                inventoryItems.add(new InventoryItem(id, name, quantity, upc, imageUrl, price));
            }
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    // Add a test item to the database for temporary functionality
    private void addTestItemToDatabase() {
        // Randomly generate data for the test item
        String name = "Test Item " + (int)(Math.random() * 100); // Random name
        int quantity = (int)(Math.random() * 100); // Random quantity
        String upc = String.valueOf((long)(Math.random() * 1000000000L)); // Random UPC
        double price = Math.round(Math.random() * 100.0 * 100.0) / 100.0; // Random price with 2 decimal places

        // Create a test InventoryItem with randomly generated data
        InventoryItem testItem = new InventoryItem(
                0, name, quantity, upc, null, price
        );

        // Insert the test item into the database
        dbHelper.addItem(testItem);

        // Notify the adapter that the data has changed
        adapter.notifyDataSetChanged();
        loadItemsFromDatabase();
    }

    // Load items from the database and populate the inventoryItems list
    private void loadItemsFromDatabase() {
        inventoryItems.clear(); // Clear the existing list
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(ItemDatabaseHelper.TABLE_INVENTORY, null, null, null, null, null, null);

        if (cursor != null) {
            int idIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_ID);
            int nameIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_ITEM_NAME);
            int quantityIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_QUANTITY);
            int upcIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_UPC);
            int imageUrlIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_IMAGE_URL);
            int priceIndex = cursor.getColumnIndex(ItemDatabaseHelper.COLUMN_PRICE);

            // Read each item from the cursor and add it to the list
            while (cursor.moveToNext()) {
                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                int quantity = cursor.getInt(quantityIndex);
                String upc = cursor.getString(upcIndex);
                double price = cursor.getDouble(priceIndex);

                String imageUrl = cursor.getString(imageUrlIndex);
                inventoryItems.add(new InventoryItem(id, name, quantity, upc, imageUrl, price));
            }
            cursor.close();
        }
        adapter.notifyDataSetChanged(); // Notify adapter about data change
    }
}
