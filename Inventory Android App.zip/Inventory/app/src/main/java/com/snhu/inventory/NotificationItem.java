package com.snhu.inventory;

public class NotificationItem {

    private String title;

    private String content;

    private boolean isRead;

    public NotificationItem(String title, String content) {
        this.title = title;
        this.content = content;
        this.isRead = false;
    }


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isRead() {
        return isRead;
    }

    public void setRead(boolean read) {
        isRead = read;
    }
}

