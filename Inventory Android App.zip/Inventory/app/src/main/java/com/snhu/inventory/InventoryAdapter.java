package com.snhu.inventory;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private String currentSortField = "name";
    private boolean isSortAscending = true;

    private List<InventoryItem> inventoryItems;
    private final ItemDatabaseHelper dbHelper;
    private Context context;

    // Define the listener interface
    public interface OnItemClickListener {
        void onItemClick(InventoryItem item);
    }

    // Listener field
    private OnItemClickListener onItemClickListener;

    // Method to set the listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    public InventoryAdapter(List<InventoryItem> inventoryItems, ItemDatabaseHelper dbHelper, Context context) {
        this.inventoryItems = inventoryItems;
        this.dbHelper = dbHelper;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        InventoryItem item = inventoryItems.get(position);
        holder.bind(item, position);
    }

    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }

    // Sorting Methods

    // Sort the list by name (ascending or descending)
    public void sortByName(boolean isAscending) {
        if (isAscending) {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getName));
        } else {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getName).reversed());
        }
        notifyDataSetChanged();
    }

    // Sort the list by quantity (ascending or descending)
    public void sortByQuantity(boolean isAscending) {
        if (isAscending) {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getQuantity));
        } else {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getQuantity).reversed());
        }
        notifyDataSetChanged();
    }

    // Sort the list by upc (ascending or descending)
    public void sortByUpc(boolean isAscending) {
        if (isAscending) {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getUpc));
        } else {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getUpc).reversed());
        }
        notifyDataSetChanged();
    }

    // Sort the list by price (ascending or descending)
    public void sortByPrice(boolean isAscending) {
        if (isAscending) {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getPrice));
        } else {
            Collections.sort(inventoryItems, Comparator.comparing(InventoryItem::getPrice).reversed());
        }
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemNameTextView, itemCountTextView, itemUpcTextView, itemPriceTextView;
        ImageView itemImageView;
        Button incrementButton, decrementButton;

        ViewHolder(View itemView) {
            super(itemView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemCountTextView = itemView.findViewById(R.id.itemCountTextView);
            itemUpcTextView = itemView.findViewById(R.id.itemUpcTextView);
            itemPriceTextView = itemView.findViewById(R.id.itemPriceText);
            itemImageView = itemView.findViewById(R.id.itemImageView);
            incrementButton = itemView.findViewById(R.id.incrementButton);
            decrementButton = itemView.findViewById(R.id.decrementButton);

            // long-press listener
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        InventoryItem item = inventoryItems.get(position);
                        // Handle the long-press event to open the ItemDetailActivity
                        Intent intent = new Intent(context, ItemDetailActivity.class);
                        intent.putExtra("itemId", item.getId()); // Pass the item ID to the ItemDetailActivity
                        context.startActivity(intent);
                    }
                    return true;
                }
            });
        }

        void bind(InventoryItem item, int position) {
            itemNameTextView.setText(item.getName());
            itemCountTextView.setText(String.format(Locale.getDefault(), "%d", item.getQuantity()));
            itemUpcTextView.setText(item.getUpc());
            itemPriceTextView.setText(String.format(Locale.getDefault(), "$%.2f", item.getPrice()));

            Uri imageUri = item.getImageUrl() != null && !item.getImageUrl().equals("default_image")
                    ? Uri.parse(item.getImageUrl())
                    : Uri.parse("android.resource://com.snhu.inventory/drawable/default_image");
            itemImageView.setImageURI(imageUri);

            incrementButton.setOnClickListener(v -> {
                item.setQuantity(item.getQuantity() + 1);
                notifyItemChanged(position);
                dbHelper.updateItem(item);
            });

            decrementButton.setOnClickListener(v -> {
                if (item.getQuantity() > 0) {
                    item.setQuantity(item.getQuantity() - 1);
                    notifyItemChanged(position);
                    dbHelper.updateItem(item);
                }
            });

            itemView.setOnClickListener(view -> {
                if (onItemClickListener != null && position != RecyclerView.NO_POSITION) {
                    onItemClickListener.onItemClick(item);
                }
            });
        }
    }
}
