package com.snhu.inventory;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PasswordResetActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText newPasswordEditText;
    private EditText confirmNewPasswordEditText;
    private Button verifyButton;
    private Button resetPasswordButton;
    private UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameEditText);
        newPasswordEditText = findViewById(R.id.newPasswordEditText);
        confirmNewPasswordEditText = findViewById(R.id.confirmNewPasswordEditText);
        verifyButton = findViewById(R.id.verifyButton);
        resetPasswordButton = findViewById(R.id.resetPasswordButton);

        // Hide password fields and reset button initially
        newPasswordEditText.setVisibility(View.GONE);
        confirmNewPasswordEditText.setVisibility(View.GONE);
        resetPasswordButton.setVisibility(View.GONE);

        // Initialize DatabaseHelper
        dbHelper = new UserDatabaseHelper(this);

        // Set onClick listeners
        verifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyUsername();
            }
        });

        resetPasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetPassword();
            }
        });
    }

    private void verifyUsername() {
        String username = usernameEditText.getText().toString();
        if (!Utils.isValidUsername(username)) {
            Toast.makeText(this, "Username must be at least 6 characters", Toast.LENGTH_LONG).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                UserDatabaseHelper.TABLE_USERS,
                new String[]{UserDatabaseHelper.COLUMN_USERNAME},
                UserDatabaseHelper.COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Enable password fields and reset button
            newPasswordEditText.setVisibility(View.VISIBLE);
            confirmNewPasswordEditText.setVisibility(View.VISIBLE);
            resetPasswordButton.setVisibility(View.VISIBLE);

            // Disable username fields and verify button
            usernameEditText.setVisibility(View.GONE);
            verifyButton.setVisibility(View.GONE);
            cursor.close();
        } else {
            Toast.makeText(this, "Username not found", Toast.LENGTH_LONG).show();
        }
    }

    private void resetPassword() {
        String username = usernameEditText.getText().toString();
        String newPassword = newPasswordEditText.getText().toString();
        String confirmNewPassword = confirmNewPasswordEditText.getText().toString();

        if (!Utils.isValidPassword(newPassword)) {
            Toast.makeText(this, "New password must be at least 6 characters and include a number", Toast.LENGTH_LONG).show();
            return;
        }

        if (!newPassword.equals(confirmNewPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_LONG).show();
            return;
        }

        String hashedPassword = Utils.hashPassword(newPassword);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabaseHelper.COLUMN_PASSWORD, hashedPassword);

        int rowsAffected = db.update(UserDatabaseHelper.TABLE_USERS, values, UserDatabaseHelper.COLUMN_USERNAME + "=?", new String[]{username});
        if (rowsAffected > 0) {
            Toast.makeText(this, "Password reset successfully", Toast.LENGTH_SHORT).show();

            // Redirect to the login screen
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish(); // Close the current activity
        } else {
            Toast.makeText(this, "Failed to reset password", Toast.LENGTH_SHORT).show();
        }
    }
}
