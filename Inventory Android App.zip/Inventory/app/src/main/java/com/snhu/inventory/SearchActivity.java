package com.snhu.inventory;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SearchInventoryAdapter searchAdapter;
    private List<InventoryItem> inventoryItems;
    private ItemDatabaseHelper dbHelper;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        dbHelper = new ItemDatabaseHelper(this);
        inventoryItems = new ArrayList<>();
        setupSearchView();
        setupRecyclerView();
        setupBarcodeScannerButton();

        // Check if the barcode scanner should be enabled
        if (getIntent().getBooleanExtra("barcodeScannerEnabled", false)) {
            new IntentIntegrator(this).initiateScan();
        }
    }

    // Setup the SearchView widget for searching inventory items
    private void setupSearchView() {
        searchView = findViewById(R.id.searchView);
        searchView.setIconified(false); // Expand the SearchView
        searchView.requestFocus(); // Request focus for input

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(searchView, 0); // Show the soft keyboard
        }

        // Define query text listeners for search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchItems(query); // Perform a search when the user submits the query
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchItems(newText); // Perform a search as the user types
                return false;
            }
        });
    }

    // Setup the RecyclerView to display search results
    private void setupRecyclerView() {
        recyclerView = findViewById(R.id.searchRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        searchAdapter = new SearchInventoryAdapter(inventoryItems, this);
        searchAdapter.setOnItemClickListener(new SearchInventoryAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(InventoryItem item) {
                // Launch the ItemDetailActivity with item details when an item is clicked
                Intent intent = new Intent(SearchActivity.this, ItemDetailActivity.class);
                intent.putExtra("itemId", item.getId()); // Pass the item ID to the detail activity
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(searchAdapter);
    }

    // Setup the barcode scanner button and handle barcode scanning result
    private void setupBarcodeScannerButton() {
        ImageButton scanBarcodeButton = findViewById(R.id.scanUpcButton);
        scanBarcodeButton.setOnClickListener(v -> new IntentIntegrator(SearchActivity.this).initiateScan());
    }

    // Handle the result of the barcode scanning activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null && result.getContents() != null) {
            // Handle the scanned barcode
            handleScannedItem(result.getContents());
        }
    }

    // Perform a search for inventory items based on the given query
    private void searchItems(String query) {
        Cursor cursor = dbHelper.searchItems(query);
        inventoryItems.clear();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Extract data from the cursor and create an InventoryItem
                int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(ItemDatabaseHelper.COLUMN_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(ItemDatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(ItemDatabaseHelper.COLUMN_QUANTITY));
                String upc = cursor.getString(cursor.getColumnIndexOrThrow(ItemDatabaseHelper.COLUMN_UPC));
                double price = cursor.getDouble(cursor.getColumnIndexOrThrow(ItemDatabaseHelper.COLUMN_PRICE));
                String imageUrl = cursor.getString(cursor.getColumnIndexOrThrow(ItemDatabaseHelper.COLUMN_IMAGE_URL));

                InventoryItem item = new InventoryItem(itemId, itemName, quantity, upc, imageUrl, price);
                inventoryItems.add(item);

            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        searchAdapter.notifyDataSetChanged(); // Update the RecyclerView with search results
    }

    // Handle a scanned item by looking up its details in the database
    private void handleScannedItem(String scannedUpc) {
        InventoryItem item = dbHelper.getItemByUpc(scannedUpc);
        if (item != null) {
            // Item found, open the detail view
            Intent intent = new Intent(SearchActivity.this, ItemDetailActivity.class);
            intent.putExtra("itemId", item.getId());
            startActivity(intent);
        } else {
            // No item found with scanned UPC
            Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
        }
    }
}
