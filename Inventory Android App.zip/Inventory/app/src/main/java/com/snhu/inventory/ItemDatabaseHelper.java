package com.snhu.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ItemDatabaseHelper extends SQLiteOpenHelper {

    // Database constants
    private static final String DATABASE_NAME = "InventoryDatabase";
    private static final int DATABASE_VERSION = 2;

    // Table and column names
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_ITEM_NAME = "item_name";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_UPC = "upc";
    public static final String COLUMN_IMAGE_URL = "image_url";
    public static final String COLUMN_PRICE = "price";

    // SQL statement to create the inventory table
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_INVENTORY + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ITEM_NAME + " TEXT, " +
                    COLUMN_QUANTITY + " INTEGER, " +
                    COLUMN_UPC + " TEXT, " +
                    COLUMN_IMAGE_URL + " TEXT, " +
                    COLUMN_PRICE + " REAL" +
                    ")";

    public ItemDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the inventory table when the database is created
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Implement database upgrade logic
        if (oldVersion < 2) {
            // Logic to add new columns (UPC, Image URL, Price) without losing existing data
            db.execSQL("ALTER TABLE " + TABLE_INVENTORY + " ADD COLUMN " + COLUMN_UPC + " TEXT");
            db.execSQL("ALTER TABLE " + TABLE_INVENTORY + " ADD COLUMN " + COLUMN_IMAGE_URL + " TEXT");
            db.execSQL("ALTER TABLE " + TABLE_INVENTORY + " ADD COLUMN " + COLUMN_PRICE + " REAL");
        }
    }

    // Method to add an item to the inventory table
    public void addItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_UPC, item.getUpc());
        values.put(COLUMN_IMAGE_URL, item.getImageUrl());
        values.put(COLUMN_PRICE, item.getPrice());

        db.insert(TABLE_INVENTORY, null, values);
        db.close();
    }

    // Method to update an item to the inventory table
    public void updateItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        values.put(COLUMN_UPC, item.getUpc());
        values.put(COLUMN_IMAGE_URL, item.getImageUrl());
        values.put(COLUMN_PRICE, item.getPrice());

        db.update(TABLE_INVENTORY, values, COLUMN_ID + " = ?", new String[]{String.valueOf(item.getId())});
        db.close();
    }


    // Method to retrieve an item by its ID
    public InventoryItem getItemById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_INVENTORY,
                new String[]{COLUMN_ID, COLUMN_ITEM_NAME, COLUMN_QUANTITY, COLUMN_UPC, COLUMN_IMAGE_URL, COLUMN_PRICE},
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null);

        InventoryItem item = null;

        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndexOrThrow(COLUMN_ID);
            int itemNameIndex = cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME);
            int quantityIndex = cursor.getColumnIndexOrThrow(COLUMN_QUANTITY);
            int upcIndex = cursor.getColumnIndexOrThrow(COLUMN_UPC);
            int imageUrlIndex = cursor.getColumnIndexOrThrow(COLUMN_IMAGE_URL);
            int priceIndex = cursor.getColumnIndexOrThrow(COLUMN_PRICE);

            int itemId = cursor.getInt(idIndex);
            String itemName = cursor.getString(itemNameIndex);
            int quantity = cursor.getInt(quantityIndex);
            String upc = cursor.getString(upcIndex);
            String imageUrl = cursor.getString(imageUrlIndex);
            double price = cursor.getDouble(priceIndex);

            item = new InventoryItem(itemId, itemName, quantity, upc, imageUrl, price);
        }

        if (cursor != null) {
            cursor.close();
        }

        return item;
    }

    // Method to retrieve an item by its UPC
    public InventoryItem getItemByUpc(String upc) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_INVENTORY,
                new String[]{COLUMN_ID, COLUMN_ITEM_NAME, COLUMN_QUANTITY, COLUMN_UPC, COLUMN_IMAGE_URL, COLUMN_PRICE},
                COLUMN_UPC + " = ?",
                new String[]{upc},
                null, null, null);

        InventoryItem item = null;

        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndexOrThrow(COLUMN_ID);
            int itemNameIndex = cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME);
            int quantityIndex = cursor.getColumnIndexOrThrow(COLUMN_QUANTITY);
            int upcIndex = cursor.getColumnIndexOrThrow(COLUMN_UPC);
            int imageUrlIndex = cursor.getColumnIndexOrThrow(COLUMN_IMAGE_URL);
            int priceIndex = cursor.getColumnIndexOrThrow(COLUMN_PRICE);

            int itemId = cursor.getInt(idIndex);
            String itemName = cursor.getString(itemNameIndex);
            int quantity = cursor.getInt(quantityIndex);
            String itemUpc = cursor.getString(upcIndex);
            String imageUrl = cursor.getString(imageUrlIndex);
            double price = cursor.getDouble(priceIndex);

            item = new InventoryItem(itemId, itemName, quantity, itemUpc, imageUrl, price);
        }

        if (cursor != null) {
            cursor.close();
        }

        return item;
    }


    // Method to search for items by name or UPC
    public Cursor searchItems(String query) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_ITEM_NAME + " LIKE ? OR " + COLUMN_UPC + " LIKE ?";
        String[] selectionArgs = new String[]{"%" + query + "%", "%" + query + "%"};

        return db.query(TABLE_INVENTORY, null, selection, selectionArgs, null, null, null);
    }

    // Method to retrieve all items from the inventory table
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_INVENTORY, null, null, null, null, null, null);
    }

    // Method to delete an item from the inventory table
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INVENTORY, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return true;
    }

    // Method to get a list of low inventory items
    public List<InventoryItem> getLowInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        List<InventoryItem> lowInventoryItems = new ArrayList<>();

        String selection = COLUMN_QUANTITY + " <= ?";
        String[] selectionArgs = new String[]{"0"};

        Cursor cursor = db.query(TABLE_INVENTORY, null, selection, selectionArgs, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                // Retrieve item ID
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));

                // Use getItemById to get the item details
                InventoryItem item = getItemById(id);

                if (item != null) {
                    lowInventoryItems.add(item);
                }
            }
            cursor.close();
        }

        return lowInventoryItems;
    }

}

