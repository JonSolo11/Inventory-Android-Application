package com.snhu.inventory;

import java.io.Serializable;

public class InventoryItem implements Serializable {
    private int id;
    private String name;
    private int quantity;
    private String upc;
    private String imageUrl;
    private double price;


    // Constructor for new items (no ID needed)
    public InventoryItem(String name, int quantity, String upc, String imageUrl, double price) {
        this.name = name;
        this.quantity = quantity;
        this.upc = upc;
        this.imageUrl = imageUrl;
        this.price = price;
    }

    // Constructor for existing items (includes ID)
    public InventoryItem(int id, String name, int quantity, String upc, String imageUrl, double price) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.upc = upc;
        this.imageUrl = imageUrl;
        this.price = price;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }
    public String getImageUrl() {
        return imageUrl;
    }
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
