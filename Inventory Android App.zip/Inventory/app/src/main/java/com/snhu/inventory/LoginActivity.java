package com.snhu.inventory;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText phoneNumberEditText;
    private UserDatabaseHelper dbHelper;
    private boolean isRegisterMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Initialize DatabaseHelper
        dbHelper = new UserDatabaseHelper(this);

        // Set OnClickListener for Login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRegisterMode) {
                    isRegisterMode = false;
                    phoneNumberEditText.setVisibility(View.GONE);
                    loginButton.setText("Login");
                    createAccountButton.setText("Register");
                } else {
                    login();
                }
            }
        });

        // Set OnClickListener for Create Account button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isRegisterMode) {
                    isRegisterMode = true;
                    phoneNumberEditText.setVisibility(View.VISIBLE);
                    loginButton.setText("Back");
                    createAccountButton.setText("Submit");
                } else {
                    // Perform registration
                    createAccount();
                }
            }
        });

        // Handle password reset link
        TextView passwordResetLink = findViewById(R.id.passwordResetLink);
        passwordResetLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to open PasswordResetActivity
                Intent intent = new Intent(LoginActivity.this, PasswordResetActivity.class);
                startActivity(intent);
            }
        });
    }

    private void login() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password cannot be empty", Toast.LENGTH_LONG).show();
            return;
        }

        String hashedPassword = Utils.hashPassword(password);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                UserDatabaseHelper.TABLE_USERS,
                new String[]{UserDatabaseHelper.COLUMN_PASSWORD},
                UserDatabaseHelper.COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null
        );

        if (cursor != null && cursor.moveToFirst()) {
            String storedPassword = cursor.getString(0);
            if (hashedPassword.equals(storedPassword)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // Intent to navigate to MainActivity
                Intent intent = new Intent(LoginActivity.this, PermissionActivity.class);
                startActivity(intent);
                finish(); // Close the LoginActivity
            } else {
                Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
            }
            cursor.close();
        } else {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String phoneNumber = phoneNumberEditText.getText().toString();

        if (!Utils.isValidUsername(username)) {
            Toast.makeText(this, "Username must be at least 6 characters", Toast.LENGTH_LONG).show();
            return;
        }

        if (!Utils.isValidPassword(password)) {
            Toast.makeText(this, "Password must be at least 6 characters and include a number", Toast.LENGTH_LONG).show();
            return;
        }

        if (!Utils.isValidPhoneNumber(phoneNumber)) {
            Toast.makeText(this, "Phone number must be exactly 10 numbers, no spaces or special characters", Toast.LENGTH_LONG).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabaseHelper.COLUMN_USERNAME, username);
        values.put(UserDatabaseHelper.COLUMN_PASSWORD, Utils.hashPassword(password));
        values.put(UserDatabaseHelper.COLUMN_PHONE_NUMBER, phoneNumber);

        long newRowId = db.insert(UserDatabaseHelper.TABLE_USERS, null, values);

        if (newRowId == -1) {
            Toast.makeText(this, "Error creating a new account", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Account successfully created", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }
    }
}
